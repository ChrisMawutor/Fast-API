from collections import Counter
from datetime import datetime, timezone
from typing import Literal, Optional

from fastapi import APIRouter, Path, Query, Response, status

from ..data import store
from ..schemas import (
    Application,
    ApplicationCreate,
    ApplicationList,
    ApplicationStats,
    ApplicationUpdate,
    ConflictError,
    ErrorResponse,
    Level,
    NotFoundError,
    Status,
    StatusUpdate,
)

router = APIRouter(prefix="/applications", tags=["Applications"])

AppId = Path(..., gt=0, description="Application id", examples=[3])

NOT_FOUND = {404: {"model": ErrorResponse, "description": "Application not found"}}
CONFLICT = {409: {"model": ErrorResponse, "description": "Conflict with current state"}}
INVALID = {422: {"model": ErrorResponse, "description": "Validation failed"}}

SortOption = Literal["id", "-id", "fullName", "-fullName", "submittedAt", "-submittedAt"]

# Legal status changes. A decided application must be reopened (back to
# pending) before it can be decided the other way.
ALLOWED_TRANSITIONS: dict[str, set[str]] = {
    Status.pending.value: {Status.accepted.value, Status.rejected.value},
    Status.accepted.value: {Status.pending.value},
    Status.rejected.value: {Status.pending.value},
}


# --- helpers (business rules) ------------------------------------------------
def now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def to_record(model, **kwargs) -> dict:
    # mode="json" turns enums, URLs and emails into plain strings for storage
    return model.model_dump(mode="json", by_alias=True, **kwargs)


def get_or_404(app_id: int) -> dict:
    item = store.get(app_id)
    if item is None:
        raise NotFoundError(f"Application with id {app_id} was not found")
    return item


def ensure_email_free(email: str, exclude_id: Optional[int] = None) -> None:
    if store.find_by_email(email, exclude_id=exclude_id):
        raise ConflictError(
            f"An application with email '{email}' already exists",
            [{"field": "email", "message": "Email is already in use"}],
        )


# --- read --------------------------------------------------------------------
# Static paths (/stats, /lookup) are declared before /{application_id}.
@router.get("", response_model=ApplicationList, responses=INVALID,
            summary="List applications (filter, search, sort, paginate)")
def list_applications(
    status_: Optional[Status] = Query(None, alias="status"),
    track: Optional[str] = Query(None, description="Exact match, case-insensitive"),
    university: Optional[str] = Query(None, description="Exact match, case-insensitive"),
    level: Optional[Level] = None,
    join_innovation_club: Optional[bool] = Query(None, alias="joinInnovationClub"),
    q: Optional[str] = Query(None, min_length=2, description="Search name, email or course"),
    sort: SortOption = Query("id", description="Prefix with - for descending"),
    limit: int = Query(20, ge=1, le=100),
    offset: int = Query(0, ge=0),
):
    items = store.all()

    if status_:
        items = [a for a in items if a["status"] == status_.value]
    if level:
        items = [a for a in items if a["level"] == level.value]
    if track:
        items = [a for a in items if a["track"].lower() == track.lower()]
    if university:
        items = [a for a in items if a["university"].lower() == university.lower()]
    if join_innovation_club is not None:
        items = [a for a in items if a["joinInnovationClub"] is join_innovation_club]
    if q:
        needle = q.lower()
        items = [
            a for a in items
            if needle in a["fullName"].lower()
            or needle in a["email"].lower()
            or needle in a["course"].lower()
        ]

    key = sort.lstrip("-")
    items.sort(key=lambda a: a[key] if key == "id" else str(a[key]).lower(),
               reverse=sort.startswith("-"))

    return {"total": len(items), "limit": limit, "offset": offset,
            "items": items[offset: offset + limit]}


@router.get("/stats", response_model=ApplicationStats, summary="Counts by status, track and university")
def application_stats():
    items = store.all()
    return {
        "total": len(items),
        "byStatus": {s.value: sum(a["status"] == s.value for a in items) for s in Status},
        "byTrack": dict(Counter(a["track"] for a in items)),
        "byUniversity": dict(Counter(a["university"] for a in items)),
        "innovationClubMembers": sum(a["joinInnovationClub"] for a in items),
    }


@router.get("/lookup", response_model=Application, responses={**NOT_FOUND, **INVALID},
            summary="Get a single application by email")
def lookup_by_email(email: str = Query(..., min_length=3, examples=["yawmensah@gmail.com"])):
    item = store.find_by_email(email)
    if item is None:
        raise NotFoundError(f"No application found for email '{email}'")
    return item


@router.get("/{application_id}", response_model=Application, responses={**NOT_FOUND, **INVALID},
            summary="Get a single application by id")
def get_application(application_id: int = AppId):
    return get_or_404(application_id)


# --- write -------------------------------------------------------------------
@router.post("", response_model=Application, status_code=status.HTTP_201_CREATED,
             responses={**CONFLICT, **INVALID}, summary="Submit a new application")
def create_application(payload: ApplicationCreate, response: Response):
    ensure_email_free(payload.email)
    record = to_record(payload)
    record["status"] = Status.pending.value
    record["submittedAt"] = now_iso()
    created = store.add(record)
    response.headers["Location"] = f"/applications/{created['id']}"
    return created


@router.put("/{application_id}", response_model=Application,
            responses={**NOT_FOUND, **CONFLICT, **INVALID}, summary="Replace an application's details")
def replace_application(payload: ApplicationCreate, application_id: int = AppId):
    get_or_404(application_id)
    ensure_email_free(payload.email, exclude_id=application_id)
    # status and submittedAt are kept; everything the applicant controls is replaced
    return store.update(application_id, to_record(payload))


@router.patch("/{application_id}", response_model=Application,
              responses={**NOT_FOUND, **CONFLICT, **INVALID}, summary="Update some fields")
def patch_application(payload: ApplicationUpdate, application_id: int = AppId):
    get_or_404(application_id)
    changes = to_record(payload, exclude_unset=True)
    if "email" in changes:
        ensure_email_free(changes["email"], exclude_id=application_id)
    return store.update(application_id, changes)


@router.patch("/{application_id}/status", response_model=Application,
              responses={**NOT_FOUND, **CONFLICT, **INVALID},
              summary="Accept, reject or reopen an application")
def change_status(payload: StatusUpdate, application_id: int = AppId):
    current = get_or_404(application_id)["status"]
    new = payload.status.value
    if new == current:
        raise ConflictError(f"Application {application_id} is already '{current}'")
    if new not in ALLOWED_TRANSITIONS[current]:
        allowed = ", ".join(sorted(ALLOWED_TRANSITIONS[current]))
        raise ConflictError(
            f"Cannot move application {application_id} from '{current}' to '{new}'. "
            f"Allowed next status: {allowed}"
        )
    return store.update(application_id, {"status": new})


@router.delete("/{application_id}", status_code=status.HTTP_204_NO_CONTENT,
               responses=NOT_FOUND, summary="Delete an application")
def delete_application(application_id: int = AppId):
    if not store.delete(application_id):
        raise NotFoundError(f"Application with id {application_id} was not found")
    return Response(status_code=status.HTTP_204_NO_CONTENT)
