# Week 1 – Backend Task: Applications API

FastAPI CRUD API for internship applications, built on in-memory mock data (no database).
Zaptek · Backend Engineering with FastAPI (Team 2).

**Live:** https://zaptek-internship.onrender.com · **Docs:** `/docs` (Swagger) and `/redoc`

## Run locally

```bash
cd week_1_backend_task
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Open http://127.0.0.1:8000/docs.

## Project structure

```
week_1_backend_task/
├── app/
│   ├── main.py              # app setup, CORS, error handlers, meta routes
│   ├── routers/
│   │   └── applications.py  # routes + business rules (duplicates, status transitions, filtering)
│   ├── schemas.py           # Pydantic models, error response shape, custom exceptions
│   └── data.py              # mock data + thread-safe in-memory store
├── requirements.txt
└── render.yaml
```

Request flow: **router → store**. Routes never touch the dicts directly, only the store's methods,
so replacing `data.py` with a real database later doesn't change the routes.

## Endpoints

| Method | Path | Description | Success |
|---|---|---|---|
| GET | `/applications` | List with filters, search, sort, pagination | 200 |
| GET | `/applications/stats` | Counts by status, track, university | 200 |
| GET | `/applications/lookup?email=` | Single application by email | 200 |
| GET | `/applications/{id}` | Single application by id | 200 |
| POST | `/applications` | Submit an application (status starts as `pending`) | 201 |
| PUT | `/applications/{id}` | Replace applicant details | 200 |
| PATCH | `/applications/{id}` | Update only the fields sent | 200 |
| PATCH | `/applications/{id}/status` | Accept / reject / reopen | 200 |
| DELETE | `/applications/{id}` | Delete | 204 |
| POST | `/admin/reset` | Restore the original mock data | 200 |
| GET | `/health` | Health check | 200 |

List query params: `status`, `track`, `university`, `level`, `joinInnovationClub`, `q` (searches name, email, course),
`sort` (`id`, `fullName`, `submittedAt`, prefix `-` for descending), `limit` (1–100, default 20), `offset`.

## Schema

| Field | Type | Rules |
|---|---|---|
| `id` | int | Server-assigned |
| `fullName` | string | 3–100 chars, letters/spaces/`-'.`, at least two names |
| `email` | email | Valid format, stored lowercase, must be unique |
| `phone` | string | Ghana number `0[235]XXXXXXXX`; `+233…` and spaces are normalized |
| `whatsappNumber` | string | Same rules; defaults to `phone` if omitted |
| `university`, `course`, `track` | string | 2–100 chars |
| `level` | enum | `1st Year` … `5th Year`, `Graduate` |
| `motivation` | string | 20–1000 chars |
| `portfolioLink`, `resumeLink` | URL, optional | Must be valid http(s) URLs |
| `joinInnovationClub` | bool | Default `false` |
| `status` | enum | `pending` \| `accepted` \| `rejected`; server-controlled |
| `submittedAt` | datetime | Server-set, UTC ISO 8601 |

Clients can't set `id`, `status` or `submittedAt` on create/update; unknown fields are rejected.

### Status rules

```
pending ──► accepted
   │  ▲        │
   ▼  └────────┘ (reopen)
rejected ──► pending
```

A decided application has to be reopened before it can be decided the other way. Illegal moves return 409.

## Errors

Every error uses one shape:

```json
{
  "error": {
    "code": "validation_error",
    "message": "Request data failed validation",
    "details": [{ "field": "phone", "message": "String should match pattern '^0[235]\\d{8}$'" }]
  }
}
```

| Code | Status | When |
|---|---|---|
| `validation_error` | 422 | Bad body, query or path values |
| `not_found` | 404 | Unknown id/email or unknown route |
| `conflict` | 409 | Duplicate email, illegal status change |
| `method_not_allowed` | 405 | Wrong HTTP method |
| `internal_error` | 500 | Anything unexpected (logged) |

## Examples

```bash
BASE=https://zaptek-internship.onrender.com

curl "$BASE/applications?status=accepted&sort=-submittedAt"
curl "$BASE/applications/3"

curl -X POST "$BASE/applications" -H "Content-Type: application/json" -d '{
  "fullName": "Kwame Boateng",
  "email": "kwame.boateng@gmail.com",
  "phone": "+233 24 123 4567",
  "university": "KNUST",
  "course": "Computer Science",
  "level": "3rd Year",
  "track": "Backend Engineering",
  "motivation": "I want to build production-grade APIs with FastAPI.",
  "portfolioLink": "https://github.com/kwameb",
  "joinInnovationClub": true
}'

curl -X PATCH "$BASE/applications/3/status" -H "Content-Type: application/json" -d '{"status": "accepted"}'
curl -X PATCH "$BASE/applications/3" -H "Content-Type: application/json" -d '{"track": "RF Systems"}'
curl -X DELETE "$BASE/applications/5"
```

## Mock data notes

- Seeded with the four applications from the brief (ids 2–5); new ids start at 6.
- Data lives in memory, so changes are lost when the server restarts. Render's free tier sleeps after inactivity,
  which also resets it. `POST /admin/reset` restores the seed on demand.
- A lock guards the store because FastAPI runs sync endpoints in a thread pool.

## Deploy on Render

New → Web Service → connect the repo, then set:

- Root Directory: `week_1_backend_task`
- Build: `pip install -r requirements.txt`
- Start: `uvicorn app.main:app --host 0.0.0.0 --port $PORT`
- Health check path: `/health`
