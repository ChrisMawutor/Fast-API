import logging

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

from .data import store
from .routers import applications
from .schemas import AppError

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("zaptek.api")

app = FastAPI(
    title="Zaptek Applications API",
    version="1.0.0",
    description=(
        "Week 1 backend task (Team 2). A CRUD API for internship applications, "
        "backed by in-memory mock data instead of a database. "
        "Data resets whenever the server restarts."
    ),
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(applications.router)


# --- error handling ----------------------------------------------------------
# Every error returns: {"error": {"code": ..., "message": ..., "details": [...]}}
def error_response(status_code: int, code: str, message: str, details=None) -> JSONResponse:
    return JSONResponse(
        status_code=status_code,
        content={"error": {"code": code, "message": message, "details": details or []}},
    )


HTTP_CODES = {400: "bad_request", 404: "not_found", 405: "method_not_allowed"}


@app.exception_handler(AppError)
async def handle_app_error(_: Request, exc: AppError):
    return error_response(exc.status_code, exc.code, exc.message, exc.details)


@app.exception_handler(RequestValidationError)
async def handle_validation_error(_: Request, exc: RequestValidationError):
    details = []
    for err in exc.errors():
        # loc looks like ("body", "fullName") or ("query", "limit")
        loc = [str(p) for p in err.get("loc", ()) if p != "body"]
        msg = err.get("msg", "Invalid value").removeprefix("Value error, ")
        details.append({"field": ".".join(loc) or None, "message": msg})
    return error_response(422, "validation_error", "Request data failed validation", details)


@app.exception_handler(StarletteHTTPException)
async def handle_http_error(_: Request, exc: StarletteHTTPException):
    return error_response(exc.status_code, HTTP_CODES.get(exc.status_code, "http_error"), str(exc.detail))


@app.exception_handler(Exception)
async def handle_unexpected(_: Request, exc: Exception):
    logger.exception("Unhandled error", exc_info=exc)
    return error_response(500, "internal_error", "Something went wrong on our side")


# --- meta routes -------------------------------------------------------------
@app.get("/", tags=["Meta"], summary="API info")
def root():
    return {
        "name": app.title,
        "version": app.version,
        "docs": "/docs",
        "redoc": "/redoc",
        "endpoints": {
            "list": "GET /applications",
            "stats": "GET /applications/stats",
            "byEmail": "GET /applications/lookup?email=",
            "single": "GET /applications/{id}",
            "create": "POST /applications",
            "replace": "PUT /applications/{id}",
            "update": "PATCH /applications/{id}",
            "changeStatus": "PATCH /applications/{id}/status",
            "delete": "DELETE /applications/{id}",
        },
    }


@app.get("/health", tags=["Meta"], summary="Health check (used by Render)")
def health():
    return {"status": "ok"}


@app.post("/admin/reset", tags=["Meta"], summary="Restore the original mock data")
def reset():
    return {"message": "Mock data restored", "count": store.reset()}
