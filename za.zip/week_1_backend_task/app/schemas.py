"""Pydantic schemas: the contract for what comes in and what goes out.

Python code uses snake_case; the JSON the API speaks uses camelCase (matching
the brief). `alias_generator=to_camel` bridges the two automatically.
"""
import re
from datetime import datetime
from enum import Enum
from typing import Annotated, Optional

from pydantic import (
    BaseModel,
    BeforeValidator,
    ConfigDict,
    EmailStr,
    Field,
    HttpUrl,
    field_validator,
    model_validator,
)
from pydantic.alias_generators import to_camel


# --- enums -------------------------------------------------------------------
class Status(str, Enum):
    pending = "pending"
    accepted = "accepted"
    rejected = "rejected"


class Level(str, Enum):
    first = "1st Year"
    second = "2nd Year"
    third = "3rd Year"
    fourth = "4th Year"
    fifth = "5th Year"
    graduate = "Graduate"


# --- reusable field types ----------------------------------------------------
def _normalize_phone(value):
    """Accept '024 556 7812', '024-556-7812' or '+233245567812'; store '0245567812'."""
    if isinstance(value, str):
        value = re.sub(r"[\s\-()]", "", value)
        if value.startswith("+233"):
            value = "0" + value[4:]
        elif value.startswith("233") and len(value) == 12:
            value = "0" + value[3:]
    return value


GhanaPhone = Annotated[
    str,
    BeforeValidator(_normalize_phone),
    Field(pattern=r"^0[235]\d{8}$", examples=["0245567812"],
          description="Ghana number, 10 digits starting with 02, 03 or 05. +233 is accepted and normalized."),
]
ShortText = Annotated[str, Field(min_length=2, max_length=100)]
Motivation = Annotated[str, Field(min_length=20, max_length=1000)]

NAME_PATTERN = re.compile(r"^[A-Za-zÀ-ÖØ-öø-ÿ][A-Za-zÀ-ÖØ-öø-ÿ'.\- ]+$")


def _check_full_name(value: str) -> str:
    value = " ".join(value.split())  # collapse repeated spaces
    if not NAME_PATTERN.match(value):
        raise ValueError("fullName may only contain letters, spaces, hyphens, apostrophes and dots")
    if len(value.split(" ")) < 2:
        raise ValueError("fullName must include at least a first name and a last name")
    return value


class CamelModel(BaseModel):
    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
        str_strip_whitespace=True,
    )


# --- core schema -------------------------------------------------------------
class ApplicationBase(CamelModel):
    full_name: Annotated[str, Field(min_length=3, max_length=100, examples=["Ama Serwaa Owusu"])]
    email: EmailStr
    phone: GhanaPhone
    whatsapp_number: GhanaPhone
    university: ShortText
    course: ShortText
    level: Level
    track: ShortText
    motivation: Motivation
    portfolio_link: Optional[HttpUrl] = None
    resume_link: Optional[HttpUrl] = None
    join_innovation_club: bool = False

    @field_validator("full_name")
    @classmethod
    def validate_full_name(cls, v: str) -> str:
        return _check_full_name(v)

    @field_validator("email")
    @classmethod
    def lowercase_email(cls, v: str) -> str:
        return v.lower()


# --- request bodies ----------------------------------------------------------
class ApplicationCreate(ApplicationBase):
    """POST / PUT body. id, status and submittedAt are server-controlled, so
    sending them is rejected (extra='forbid')."""

    model_config = ConfigDict(extra="forbid")

    # Optional on input: falls back to `phone` when omitted.
    whatsapp_number: Optional[GhanaPhone] = None

    @model_validator(mode="after")
    def default_whatsapp(self):
        if self.whatsapp_number is None:
            self.whatsapp_number = self.phone
        return self


NULLABLE_FIELDS = {"portfolio_link", "resume_link"}


class ApplicationUpdate(CamelModel):
    """PATCH body: every field optional, only the ones sent are changed."""

    model_config = ConfigDict(extra="forbid")

    full_name: Optional[Annotated[str, Field(min_length=3, max_length=100)]] = None
    email: Optional[EmailStr] = None
    phone: Optional[GhanaPhone] = None
    whatsapp_number: Optional[GhanaPhone] = None
    university: Optional[ShortText] = None
    course: Optional[ShortText] = None
    level: Optional[Level] = None
    track: Optional[ShortText] = None
    motivation: Optional[Motivation] = None
    portfolio_link: Optional[HttpUrl] = None
    resume_link: Optional[HttpUrl] = None
    join_innovation_club: Optional[bool] = None

    @field_validator("full_name")
    @classmethod
    def validate_full_name(cls, v):
        return _check_full_name(v) if v is not None else v

    @field_validator("email")
    @classmethod
    def lowercase_email(cls, v):
        return v.lower() if v is not None else v

    @model_validator(mode="after")
    def check_payload(self):
        if not self.model_fields_set:
            raise ValueError("Provide at least one field to update")
        nulls = [
            to_camel(f) for f in self.model_fields_set
            if getattr(self, f) is None and f not in NULLABLE_FIELDS
        ]
        if nulls:
            raise ValueError(f"These fields cannot be null: {', '.join(sorted(nulls))}")
        return self


class StatusUpdate(CamelModel):
    model_config = ConfigDict(extra="forbid")
    status: Status


# --- responses ---------------------------------------------------------------
class Application(ApplicationBase):
    id: int
    status: Status
    submitted_at: datetime


class ApplicationList(CamelModel):
    total: int = Field(description="Matches before pagination")
    limit: int
    offset: int
    items: list[Application]


class ApplicationStats(CamelModel):
    total: int
    by_status: dict[str, int]
    by_track: dict[str, int]
    by_university: dict[str, int]
    innovation_club_members: int


class ErrorDetail(BaseModel):
    field: Optional[str] = None
    message: str


class ErrorBody(BaseModel):
    code: str
    message: str
    details: list[ErrorDetail] = []


class ErrorResponse(BaseModel):
    error: ErrorBody


# --- application exceptions --------------------------------------------------
# Raised by the route logic; main.py turns them into ErrorResponse JSON.
class AppError(Exception):
    status_code = 400
    code = "bad_request"

    def __init__(self, message: str, details: Optional[list[dict]] = None):
        super().__init__(message)
        self.message = message
        self.details = details or []


class NotFoundError(AppError):
    status_code = 404
    code = "not_found"


class ConflictError(AppError):
    status_code = 409
    code = "conflict"
