"""Mock data layer.

There is no database. Records live in memory as plain dicts (camelCase keys,
JSON-safe values), exactly the shape given in the task brief. Everything else
in the app talks to the data through `ApplicationStore`, so swapping this for a
real database later only means rewriting this one file.
"""
from copy import deepcopy
from threading import Lock
from typing import Optional

SEED_APPLICATIONS: list[dict] = [
    {
        "id": 2,
        "fullName": "Ama Serwaa Owusu",
        "email": "amaserwaa@gmail.com",
        "phone": "0245567812",
        "whatsappNumber": "0245567812",
        "university": "University of Ghana",
        "course": "Computer Engineering",
        "level": "2nd Year",
        "track": "Embedded Systems",
        "motivation": "I want to gain hands-on experience in embedded systems and IoT development.",
        "portfolioLink": "https://github.com/amase",
        "resumeLink": "https://linkedin.com/in/amase",
        "joinInnovationClub": True,
        "status": "accepted",
        "submittedAt": "2026-05-04T10:12:45Z",
    },
    {
        "id": 3,
        "fullName": "Yaw Mensah",
        "email": "yawmensah@gmail.com",
        "phone": "0558876123",
        "whatsappNumber": "0558876123",
        "university": "KNUST",
        "course": "Electrical Engineering",
        "level": "4th Year",
        "track": "Radar & RF Systems",
        "motivation": "To improve my knowledge in RF systems, radar engineering, and wireless communications.",
        "portfolioLink": "https://github.com/yawmensah",
        "resumeLink": "https://linkedin.com/in/yawmensah",
        "joinInnovationClub": True,
        "status": "pending",
        "submittedAt": "2026-05-05T08:45:30Z",
    },
    {
        "id": 4,
        "fullName": "Priscilla Adjei",
        "email": "priscilla.adjei@gmail.com",
        "phone": "0203344556",
        "whatsappNumber": "0203344556",
        "university": "Ashesi University",
        "course": "Software Engineering",
        "level": "3rd Year",
        "track": "Backend Engineering",
        "motivation": "I want to strengthen my backend engineering skills using FastAPI and modern software architecture.",
        "portfolioLink": "https://github.com/priscillaadjei",
        "resumeLink": "https://linkedin.com/in/priscillaadjei",
        "joinInnovationClub": True,
        "status": "accepted",
        "submittedAt": "2026-05-06T14:18:22Z",
    },
    {
        "id": 5,
        "fullName": "Daniel Kofi Asante",
        "email": "danielasante@gmail.com",
        "phone": "0277788990",
        "whatsappNumber": "0277788990",
        "university": "UENR",
        "course": "Biomedical Engineering",
        "level": "2nd Year",
        "track": "Biomedical Systems",
        "motivation": "To explore biomedical monitoring systems and healthcare technology innovations.",
        "portfolioLink": "https://github.com/danielasante",
        "resumeLink": "https://linkedin.com/in/danielasante",
        "joinInnovationClub": False,
        "status": "rejected",
        "submittedAt": "2026-05-07T11:05:10Z",
    },
]


class ApplicationStore:
    """Thread-safe in-memory store.

    FastAPI runs plain `def` endpoints in a thread pool, so two requests can
    touch the dict at the same time. The lock keeps id generation and
    read-modify-write updates consistent.
    """

    def __init__(self, seed: list[dict]):
        self._seed = deepcopy(seed)
        self._lock = Lock()
        self._load()

    def _load(self) -> None:
        self._items: dict[int, dict] = {a["id"]: deepcopy(a) for a in self._seed}
        self._next_id = max(self._items, default=0) + 1

    # --- reads -------------------------------------------------------------
    def all(self) -> list[dict]:
        with self._lock:
            return [deepcopy(a) for a in self._items.values()]

    def get(self, app_id: int) -> Optional[dict]:
        with self._lock:
            item = self._items.get(app_id)
            return deepcopy(item) if item else None

    def find_by_email(self, email: str, exclude_id: Optional[int] = None) -> Optional[dict]:
        email = email.lower()
        with self._lock:
            for item in self._items.values():
                if item["email"].lower() == email and item["id"] != exclude_id:
                    return deepcopy(item)
        return None

    # --- writes ------------------------------------------------------------
    def add(self, data: dict) -> dict:
        with self._lock:
            record = {"id": self._next_id, **data}
            self._items[self._next_id] = record
            self._next_id += 1
            return deepcopy(record)

    def update(self, app_id: int, changes: dict) -> Optional[dict]:
        with self._lock:
            if app_id not in self._items:
                return None
            self._items[app_id].update(changes)
            return deepcopy(self._items[app_id])

    def delete(self, app_id: int) -> bool:
        with self._lock:
            return self._items.pop(app_id, None) is not None

    def reset(self) -> int:
        with self._lock:
            self._load()
            return len(self._items)


store = ApplicationStore(SEED_APPLICATIONS)
